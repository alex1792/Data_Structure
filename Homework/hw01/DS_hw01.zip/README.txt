READ THIS FILE BEFORE YOU USE THE PROGRAM
--------------------------------------------------------------------------------------------

Introduction:

This program is to compare two puzzles whether they can merge or not.
The program can only compare two 3*3 matrix. The rule of merging is
simple, the movable puzzle can do rotation and translation. The program
will rotate only 90, 180, 270 degrees only, and translate only up, down,
left and right. Both rotation and translation can happen at the same time.
If you type in the wrong format, the program might output the wrong consequences.
--------------------------------------------------------------------------------------------

Input:

Firstly, you have to type in an integer that represent how many cases
you want to test. Second, you the type in your two 3*3 puzzles. First
3*3 array is your immovable puzzle, and the other one is your movable
puzzle. In the immovable puzzle, the element that is waiting to be 
merged should be '0', and the elements that are already known should 
be '1'. Just like the immovable puzzle, the elements of movable puzzle 
that are waiting to be merged with immovable puzzle should be '2', 
and the other elements should be '0'.

For example, if you have two cases, your input would be like:

2    ____ this is your test cases, each case contains an immovable and a movable puzzle.
111
011
001  ____ above is immovable puzzle
002
022
000  ____ above is movable puzzle
111
011
001  ____ above is immovable puzzle
000
000
222  ____ above is movable puzzle
--------------------------------------------------------------------------------------------

Output:

If two puzzle can merge, the the program will print out "YES" and the consequence.
If not, the program will output "NO".

For example, if you input the example input above mentioned, the output would be like:

YES
111
211
221
NO

--------------------------------------------------------------------------------------------

Contact us

If you have any question about the program, contack me by e-mial address below.

Name:Yu Hung Kung
ID:408410046
DEPARTMENT:Department of Computer Science and Information Engineering
EMAIL ADDRESS:yuhongg374@gmail.com

--------------------------------------------------------------------------------------------