READ THIS FILE BEFORE YOU USE THE PROGRAM
-------------------------------------------------------------------------------------------------------------

Introduction:
	
	This program is to represent the procedure of merge sort. By input data form users, then the program 
output evrey steps of quick sort. And lastly, find the minimum gap between elements.
	
-------------------------------------------------------------------------------------------------------------

Solving Logic:
	
	Firstly, the program has to deal with the input data. I decided to write a "getWord" function to 
seperate different data. After that, data will saved in a array. Then, called the merge sort function to 
sort the array. In the merge sort function, the program first merge 2 element, the times 2, until it's less
than the total data number. After merge, print out the whole array to show that how merge sort works. Lastly,
using the function called minimumGap to find the least gap in the sorted array. 

-------------------------------------------------------------------------------------------------------------

Input:

	43, 10, 84, 37, 95, 71, 29, 57, 62

-------------------------------------------------------------------------------------------------------------

Output:

	10, 43, 37, 84, 71, 95, 29, 57, 62
	10, 37, 43, 84, 29, 57, 71, 95, 62
	10, 29, 37, 43, 57, 71, 84, 95, 62
	10, 29, 37, 43, 57, 62, 71, 84, 95
	Minimum gap: 5
	
	
-------------------------------------------------------------------------------------------------------------

Contact us

If you have any question about the program, contack me by e-mial address below.

Name:Yu Hung Kung
ID:408410046
DEPARTMENT:Department of Computer Science and Information Engineering
EMAIL ADDRESS:yuhongg374@gmail.com

-------------------------------------------------------------------------------------------------------------