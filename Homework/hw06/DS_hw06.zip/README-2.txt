READ THIS FILE BEFORE YOU USE THE PROGRAM
-------------------------------------------------------------------------------------------------------------

Introduction:
	
	This program is to represent the procedure of selection sort. By input data form users, then the program 
output evrey steps of selection sort.
	
-------------------------------------------------------------------------------------------------------------

Solving Logic:
	
	Firstly, the program has to deal with the input data. I decided to write a "getWord" function to 
seperate different data. After that, data will saved in a array. Then, called the selection sort function to 
sort the array. After every swap, print out the whole array to show that how selection sort works.

-------------------------------------------------------------------------------------------------------------

Input:

	43, 10, 84, 37, 95, 71, 29, 57, 62

-------------------------------------------------------------------------------------------------------------

Output:

	10, 43, 84, 37, 95, 71, 29, 57, 62
	10, 29, 84, 37, 95, 71, 43, 57, 62
	10, 29, 37, 84, 95, 71, 43, 57, 62
	10, 29, 37, 43, 95, 71, 84, 57, 62
	10, 29, 37, 43, 57, 71, 84, 95, 62
	10, 29, 37, 43, 57, 62, 84, 95, 71
	10, 29, 37, 43, 57, 62, 71, 95, 84
	10, 29, 37, 43, 57, 62, 71, 84, 95
	
	
-------------------------------------------------------------------------------------------------------------

Contact us

If you have any question about the program, contack me by e-mial address below.

Name:Yu Hung Kung
ID:408410046
DEPARTMENT:Department of Computer Science and Information Engineering
EMAIL ADDRESS:yuhongg374@gmail.com

-------------------------------------------------------------------------------------------------------------